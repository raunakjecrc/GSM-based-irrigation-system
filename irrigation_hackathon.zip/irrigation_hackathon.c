#include<avr/io.h>
#include<util/delay.h>
ADC_init(int ch)
{
ADMUX=ch|0x40;
ADCSRA=0b11010111;
while((ADCSRA&0x10)==0);
return ADC;
}
 void lcd_number(int ch)
 {
  if(ch==0)
  {
   lcd_data(48);
   }
   int x;
   while (ch!=0)
   {
   lcd_loc(0x04);
   x=ch%10;
   lcd_data(48+x);
   ch=ch/10;
  }
 }
void lcd_loc(char loc)
 {
  PORTB=((loc&0xF0)|0x04);
 PORTB=PORTB-0x04;
 _delay_ms(10);
 PORTB=(((loc<<4)&0xF0)|0x04);
 PORTB=(PORTB-0x04);
 _delay_ms(10);
 }
 void lcd_data(char data)
 {
  PORTB=((data&0xF0)|0x05);
  PORTB=PORTB-0x04;
  _delay_ms(10);
  PORTB=(((data<<4)&0xF0)|0x05);
  PORTB=PORTB-0x04;
  _delay_ms(10);
  }

void lcd_init()
{
 lcd_loc(0x02);
 lcd_loc(0x28);
 lcd_loc(0x0c);
 lcd_loc(0x06);
 }

void init()
{
  UBRRL=51;
 UBRRH=0;
 UCSRB=0x18;
 UCSRC=0x8e;
}
  void send(char send)
  {
    while((UCSRA & 0x20)==0);
	UDR=send;
	}

	char rec(void)
	{
	 while ((UCSRA & 0x80)==0);
	 return UDR;
	 }
void send_str(char*str)/*FUNCTION FOR ADDING STRING*/
	 {
	  int i=0;
	  while(str[i]!='\0')
	  {
	   send(str[i]);
	   i++;
	   }
	   }
int main()
{
init();
DDRC=0b11111111;
while(1)
{
int x;
x=ADC_init(0);
lcd_loc(0x85);
lcd_number(x);
_delay_ms(10);
if(x>=800)
{ 
send_str("AT");
_delay_ms(100);
send(0x0d);
_delay_ms(1000);
send_str("AT+CMGF=1");
_delay_ms(1000);
send(0x0d);
_delay_ms(1000);
send_str("AT+CMGS=\"9785938545\"");
send_str("Irrigation is omplete....PLEASE TURN OF YOUR MOTOR.");
_delay_ms(1000);
send(0x1A);
_delay_ms(500000);
}
}
return 0;
}
